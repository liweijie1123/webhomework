/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2022-03-07 21:22:09
 * @version $Id$
 */

var x = document.querySelectorAll(".m-item");
x[0].addEventListener('click',(e)=>{
	 x[0].style.color = 'red';
}) ;

x[1].addEventListener('click',()=>{
	 var today = new Date();
	 var y = today.getFullYear();
	 var m = today.getMonth()+1;
	 var d = today.getDate();
	 m = checkTime(m);
	 d = checkTime(d);
	 document.querySelector("h1").innerHTML=y+"-"+m+"-"+d;
});

x[2].addEventListener('click',()=>{
	x[2].classList.add("fn-active");
});

x[3].addEventListener('click',()=>{
	 var paren = document.querySelector("ul");
	 paren.removeChild(x[7]);
}) ;

x[4].addEventListener('click',()=>{
	 window.open("https://www.taobao.com");
});

x[5].addEventListener('click',()=>{
	 var paren = document.querySelector("ul");
	 var l = document.createElement("li");
	 var node = document.createTextNode("p9");
	 l.appendChild(node);
	 paren.appendChild(l);
	 l.addEventListener('click',()=>{
		alert(l.innerHTML);
	 });
});
x[6].addEventListener('click',()=>{
	var w = screen.availWidth+'px';
   document.getElementById("one").style.width=w;
});


function checkTime(i) {
	 if(i<10) {
		  i="0"+i;
	 }
	 return i;
}

for(let i = 0;i<x.length;i++){
	var y = x[i];
	y.addEventListener('click',()=>{
	let res  = x[i].innerHTML;
	 alert(res);
	});
}